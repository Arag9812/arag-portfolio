import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Twitter } from "lucide-react";
import { motion } from "framer-motion";

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-white dark:bg-zinc-900 text-zinc-800 dark:text-white p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold">Arag's Portfolio</h1>
        <p className="text-zinc-500 mt-2">Solving problems through AI, automation, and community</p>
        <div className="mt-4 flex justify-center gap-4">
          <a href="https://twitter.com/hammed_roqeeb8" target="_blank" rel="noopener noreferrer">
            <Button variant="outline" className="flex items-center gap-2">
              <Twitter className="w-4 h-4" /> Twitter
            </Button>
          </a>
        </div>
      </header>

      <section className="grid md:grid-cols-2 gap-6 mb-12">
        {[
          { title: "Chatbot Development", desc: "Building smart, responsive bots for websites, DMs, and workflows. Projects: Custom WhatsApp Lead Bot for a local fashion brand; Telegram order manager bot for small-scale crypto traders." },
          { title: "Digital Marketing", desc: "Campaigns that get results — from strategy to execution. Projects: SEO content plan for a local health blog; IG growth for an indie musician with hashtag automation." },
          { title: "Community Moderation", desc: "Keeping online spaces safe, engaging, and on-brand. Projects: Managed a Facebook group for a digital nomad community; Telegram NFT chat moderation for a small art collective." },
          { title: "Content Writing", desc: "Words that hook, inform, and convert — for any platform. Projects: Long-form blog content for an under-the-radar climate startup; Twitter threads for a solopreneur’s productivity niche." },
          { title: "Workflow Automation", desc: "Saving time through tools like Zapier, Make, and custom bots. Projects: Automated newsletter-to-Twitter posting for a personal finance blogger; Google Form to Notion CRM integration for a coaching brand." },
          { title: "Website Design & Development", desc: "Simple, fast, and beautiful websites built with modern stacks. Projects: Portfolio site for a student photographer; One-page business site for a boutique skincare line." }
        ].map((skill, idx) => (
          <motion.div key={idx} whileHover={{ scale: 1.02 }}>
            <Card className="rounded-2xl shadow-md">
              <CardContent className="p-4">
                <h2 className="text-xl font-semibold mb-2">{skill.title}</h2>
                <p className="text-sm text-zinc-600 dark:text-zinc-300">{skill.desc}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-4">Live Client Projects</h2>
        <p className="text-zinc-600 dark:text-zinc-300 mb-2">This section pulls in real-time info from current clients.</p>
        <div className="bg-zinc-100 dark:bg-zinc-800 rounded-xl p-4 text-sm">
          <p>Client: Tesla Crypto Giveaway Awareness Campaign (Simulation Project)</p>
          <p>Status: 🔴 Ongoing</p>
        </div>
      </section>

      <section className="mb-12 max-w-xl mx-auto">
        <h2 className="text-2xl font-bold mb-4 text-center">Work With Me</h2>
        <form className="bg-zinc-100 dark:bg-zinc-800 rounded-xl p-6 space-y-4">
          <input type="text" placeholder="Your Name" className="w-full p-2 rounded-lg bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white" required />
          <input type="email" placeholder="Your Email" className="w-full p-2 rounded-lg bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white" required />
          <textarea placeholder="Your Message or Project Brief" className="w-full p-2 h-28 rounded-lg bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white" required />
          <Button type="submit" className="w-full">Send Message</Button>
        </form>
      </section>

      <footer className="text-center text-sm text-zinc-500 mt-10">
        © {new Date().getFullYear()} Arag. All rights reserved.
      </footer>
    </div>
  );
}
